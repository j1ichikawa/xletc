How to use XLStylesTool.EXE

Description:

This OOXML based tool removes unused cell styles, �stubborn styles� that you can't delete through
Excel UI, bad named ranges, named ranges with external references, unhides non-system created 
hidden named ranges. This tool will work on workbooks with protected sheets and read-only password
protected workbooks in about 1-2 sec.

Features and options

Styles:
  
Feature: removes all unused styles from the workbook. Unused style = style that is defined in the
workbook, but is not used in any cells. 

Option: has an option to force all cell styles to �Normal�. <- Produces the best results when it 
comes to size and workbook stability. 

IMPORTANT: you will NOT lose any cell formatting if you force all styles to 'Normal'. This option
simply resets cell style property to 'Normal' and doesn't alter any of already applied format 
settings. 

This option will get you the most stable and the cleanest version of your workbook. If your file
scan shows that Styles Max ID is not equal to Style Node Count minus 1 (this is an indication 
that you have very serious styles related corruption in the file) I strongly recommend that you 
force all styles to 'Normal'. 

Named Ranges:

Feature: removes all bad named ranges. Criteria for bad named range = named range that refers to �#REF!�.

Option: has an option to remove named ranges that refer to external sources.  These typically 
contribute to a huge workbook size bloat and most users are unaware that they even have huge 
caches in their workbooks because they have been hauling them around literally for years.

Option: has an option to unhide hidden named ranges.  Handles cases where named ranges are hidden 
and therefore are invisible to the users that are trying to clean up the workbook manually. 
NOTE: system generated named ranges with valid references will remain untouched and hidden.


The app user has the ability to analyze the impact of various selected options on the file and 
assess the impact of all selections before saving the changes. The actual file won�t be altered 
and written to disk until you choose to do so. However, the file should be saved via Excel 
client to complete the cleanup process. Excel file save process does a lot of work to finish the 
process of getting rid of unused styles, unused custom number formats, unused cached data, etc�
You may expect workbook sizes to drop significantly.
In some extreme cases I've seen size drops from 4MB down to 40KB after a cleanup with subsequent 
Excel client save.

Limitations:
OOXML tool limitations vs. VBA tools: it won�t work on a fully encrypted workbook � a workbook 
with a password to open it or binary files (files with xlsb extensions).  
